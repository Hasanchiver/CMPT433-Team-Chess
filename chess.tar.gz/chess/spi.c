
#include "spi.h"
#include "global.h"
#include "lcd.h"


#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <unistd.h>


int spi_fd = 0;			//Global variable, must initialize by spiInit() before use



static struct timespec trans_delay = { .tv_sec = 0, .tv_nsec = SPI_TRANSFER_INTERMEDIATE_DELAY * 1000000 };




int spiInit(){

	//Setting up the linux SPI environment
	system("echo BB-SPIDEV0 > /sys/devices/platform/bone_capemgr/slots");
	system("echo cape_enable=bone_capemgr.enable_partno=BB-SPIDEV0 > /boot/uEnv.txt");

	//Requiring the spi file descriptor
	spi_fd = open("/dev/spidev1.0", O_RDWR);

    if(spi_fd < 0) {
    	return -1;
    }

    return 0;
}




int spi_write(uint8_t reg, uint8_t data){

	uint8_t cmd_write = RA8875_CMDWRITE, data_write = RA8875_DATAWRITE;

	write(spi_fd, &cmd_write, 1);
	write(spi_fd, &reg, 1);
	
	nanosleep(&trans_delay, NULL);

	write(spi_fd, &data_write, 1);
	write(spi_fd, &data, 1);

	nanosleep(&trans_delay, NULL);


	return 0;
}





uint8_t spi_read(uint8_t reg){


	uint8_t cmd_write = RA8875_CMDWRITE, data_read = RA8875_DATAREAD, val = 0;
	uint8_t rd_buff[1];


	write(spi_fd, &cmd_write, 1);
	write(spi_fd, &reg, 1);
	
	nanosleep(&trans_delay, NULL);

	write(spi_fd, &data_read, 1);
	write(spi_fd, &val, 1);

	if ( read(spi_fd, &rd_buff, 1) != 1){
		//REVISIT: ERROR HANDLING
		//...
		printf("error in spi.c, you can find me easily\n");
		exit(EXIT_FAILURE);
	}
	
	printf("read : %d\n", rd_buff[0]);

	return rd_buff[0];
}



