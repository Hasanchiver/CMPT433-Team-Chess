
#ifndef _SPI_H
#define _SPI_H

#include <stdint.h>

#define SPI_TRANSFER_INTERMEDIATE_DELAY						1L		//In milliseconds






extern int spi_fd;

int spi_write(uint8_t reg, uint8_t data);
uint8_t spi_read(uint8_t reg);




#endif

