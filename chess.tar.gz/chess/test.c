#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>


#define TEST 10







int main()
{

	printf("%d\n", &TEST);

    return 0;
}