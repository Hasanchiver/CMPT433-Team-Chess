

#include "global.h"
#include "spi.h"
#include "lcd.h"
#include "gpio.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//NOTE : dir == 0 -> in, otherwise, out
int gpioInit(int port, int dir, int val){

	char s[70];

	sprintf(s, "echo %d > /sys/class/gpio/export", port);
	system(s);
	sprintf(s, "echo %s > /sys/class/gpio/gpio%d/direction", (dir == 0) ? "in" : "out", port);
	system(s);
	sprintf(s, "echo %d > /sys/class/gpio/gpio%d/direction", (val == 0) ? 0 : 1, port);
	system(s);

	return 0;		//I will not handle the error in this first version
}


int gpio_write(int port, int val){

	char s[70];
	sprintf(s, "echo %d > /sys/class/gpio/gpio%d/value", (val == 0) ? 0 : 1, port);
	system(s);
	return 0;
}

int gpio_setDirection(int port, int dir){

	char s[70];
	sprintf(s, "echo %s > /sys/class/gpio/gpio%d/direction", (dir == 0) ? "in" : "out", port);
	system(s);
	return 0;
}







