
#include "global.h"
#include "spi.h"
#include "lcd.h"
#include "gpio.h"


#include <time.h>
#include <stdio.h>
#include <stdlib.h>


static int lcd_width = 800;
static int lcd_height = 480;
static struct timespec time_delay;





static void delay(int miliseconds);
int gpioInit(int port, int dir, int val);


int lcdInit(){


	gpioInit(RST_PIN, GPIO_OUT, 0);

	//Power cycle the LCD by writing 1, 0, 1 to its RST pin
	gpio_write(RST_PIN, 1);
	delay(1);
	gpio_write(RST_PIN, 0);
	delay(1);
	gpio_write(RST_PIN, 1);
	delay(1);


	

	//Reading the register address 0 and wait for a 0x75 reply
	uint8_t reply = spi_read(0);
	if(reply != 0x75){
		printf("Wrong reply\n");
		exit(EXIT_FAILURE);
	}

	printf("I get correct answer, cheers\n");











	return 0;			//I will not handle the error in this first version

}

static void delay(int miliseconds){
	time_delay.tv_sec = 0;
	time_delay.tv_nsec = miliseconds * 1000000L;

	nanosleep(&time_delay, NULL);
}