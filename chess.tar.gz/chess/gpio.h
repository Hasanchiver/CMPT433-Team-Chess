#ifndef _GPIO_H
#define _GPIO_H







int gpio_write(int port, int val);
int gpio_setDirection(int port, int dir);









#endif

